<?php

namespace App\Livewire\EcomxFashion;

use App\Livewire\Concerns\TogglesWishlist;
use App\Models\ProductAttributeValueOrder;
use App\Models\products;
use App\Support\EcomxFashion\Catalog;
use Livewire\Component;
use Livewire\Attributes\Layout;

#[Layout('ecomx-fashion.layouts.ecomx_fashion')]
class Product extends Component
{
    use TogglesWishlist;

    public string $slug = 'sculpted-wool-coat';
    public bool $flashSale = true;
    public ?int $productId = null;

    public array $product = [
        'name' => 'Sculpted Wool Coat',
        'cat' => 'Outerwear',
        'price' => 12900,
        'sale' => 9900,
        'desc' => 'Cut from double-faced Italian wool with a sculpted shoulder and hidden closure. Fully lined in cupro, finished by hand in our Dhaka atelier. Falls just below the knee.',
    ];

    public array $media = [
        ['img'=>'photo-1539109136881-3be0616acf4b','video'=>false],
        ['img'=>'photo-1483985988355-763728e1935b','video'=>false],
        ['img'=>'photo-1445205170230-053b83016050','video'=>false],
        ['img'=>'photo-1524504388940-b1c1722653e1','video'=>false],
        ['img'=>'photo-1509631179647-0177331693ae','video'=>true],
    ];

    public array $colors = [
        ['name'=>'Camel','hex'=>'#C8B49A','main'=>'photo-1539109136881-3be0616acf4b'],
        ['name'=>'Noir','hex'=>'#111111','main'=>'photo-1483985988355-763728e1935b'],
        ['name'=>'Sage','hex'=>'#6B6F63','main'=>'photo-1445205170230-053b83016050'],
        ['name'=>'Camel / Noir','hex'=>'#C8B49A','hex2'=>'#111111','main'=>'photo-1524504388940-b1c1722653e1'],
    ];

    public array $sizes = ['XS','S','M','L','XL','2XL','Unstitched','Free Size'];

    public bool $hasRealVariants = false;
    public array $variantMatrix = [];

    public array $specs = [
        ['Material','100% Italian wool, 480 gsm'],
        ['Lining','Cupro'],
        ['Fit','Regular, falls below knee'],
        ['Closure','Hidden two-button'],
        ['Origin','Made in Dhaka, Bangladesh'],
        ['Care','Dry clean only'],
        ['SKU','SF-WC-1042'],
    ];

    public function mount(?string $slug = null): void
    {
        if ($slug) $this->slug = $slug;

        // Gallery/colours/sizes below stay demo data (not wired to real
        // ProductAttribute/ProductVariant records yet) — this only swaps in
        // the real product's identity/price/description where one exists,
        // so actions that need a genuine product_id (wishlist, add-to-cart)
        // have one to work with.
        $p = products::where('slug', $this->slug)->where('status', 1)->first();

        if ($p) {
            $this->productId = $p->id;
            $this->flashSale = (bool) $p->discount_price;
            $this->product = [
                'name' => $p->name,
                'cat' => $p->segment?->name ?? $this->product['cat'],
                'price' => (float) $p->price,
                'sale' => $p->discount_price ? (float) $p->discount_price : $this->product['sale'],
                'desc' => $p->description ?: $this->product['desc'],
            ];

            $this->loadRealVariants($p);
        }
    }

    /**
     * Swaps the demo colours/sizes for real ProductAttribute/ProductVariant
     * data when the product actually has variants — same matrix shape
     * ProductGalleryBuyBox (legacy theme) builds, so addToCart() can resolve
     * a real variant id. Products with no variants keep the demo colour/size
     * pickers untouched (cosmetic only — add-to-cart still uses the real
     * product id, just with no variantId).
     */
    private function loadRealVariants(products $p): void
    {
        $variants = $p->variants()->with('values.attribute')->where('is_active', true)->get();

        if ($variants->isEmpty()) {
            return;
        }

        $colorValues = [];
        $sizeValues = [];

        foreach ($variants as $variant) {
            foreach ($variant->values as $value) {
                $attrName = $value->attribute?->name;
                if ($attrName === 'Color' && ! isset($colorValues[$value->id])) {
                    $colorValues[$value->id] = $value;
                } elseif ($attrName === 'Size' && ! isset($sizeValues[$value->id])) {
                    $sizeValues[$value->id] = $value;
                }
            }
        }

        if (empty($colorValues) && empty($sizeValues)) {
            return;
        }

        $this->hasRealVariants = true;

        $productOrder = ProductAttributeValueOrder::where('product_id', $p->id)
            ->pluck('sort_order', 'product_attribute_value_id');
        $orderFor = fn ($v) => [$productOrder[$v->id] ?? (1_000_000 + $v->sort_order), $v->id];

        if (! empty($colorValues)) {
            $this->colors = collect($colorValues)
                ->sortBy($orderFor)
                ->values()
                ->map(fn ($v) => [
                    'name' => $v->value,
                    'hex' => $v->meta ?: '#CCCCCC',
                    'main' => null,
                ])->all();
        }

        if (! empty($sizeValues)) {
            $this->sizes = collect($sizeValues)
                ->sortBy($orderFor)
                ->values()
                ->pluck('value')
                ->all();
        }

        foreach ($variants as $variant) {
            $colorName = null;
            $sizeName = null;
            foreach ($variant->values as $value) {
                if ($value->attribute?->name === 'Color') {
                    $colorName = $value->value;
                } elseif ($value->attribute?->name === 'Size') {
                    $sizeName = $value->value;
                }
            }

            $key = ($colorName ?? '*') . '|' . ($sizeName ?? '*');
            $this->variantMatrix[$key] = [
                'variantId' => $variant->id,
                'price' => (float) $variant->price,
                'salePrice' => $variant->discount_price !== null ? (float) $variant->discount_price : null,
                'stock' => $variant->stock,
            ];
        }
    }

    public function getIsWishedProperty(): bool
    {
        if (! $this->productId) {
            return false;
        }

        return products::find($this->productId)?->isWishedBy(request()->cookie('_sfdid')) ?? false;
    }

    public function render()
    {
        $all = Catalog::products();
        return view('ecomx-fashion.livewire.product', [
            'reviews' => Catalog::reviews(),
            'related' => array_slice($all, 1),
        ]);
    }
}
