<section class="container section" aria-label="Why Seldom Fashion loading">
    <div class="faq">
        <div style="display:flex;flex-direction:column;gap:24px">
            <div class="skel skel--text" style="width:70%;height:36px"></div>
            <div class="skel skel--text" style="width:90%;height:60px"></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                @for($i = 0; $i < 4; $i++)
                    <div class="skel" style="border-radius:12px;height:70px"></div>
                @endfor
            </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:16px">
            @for($i = 0; $i < 6; $i++)
                <div class="skel skel--text" style="height:52px"></div>
            @endfor
        </div>
    </div>
</section>
