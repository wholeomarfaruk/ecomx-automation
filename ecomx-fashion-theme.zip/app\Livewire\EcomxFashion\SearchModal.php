<?php

namespace App\Livewire\EcomxFashion;

use App\Models\products;
use Livewire\Component;

class SearchModal extends Component
{
    public string $q = '';

    public function getResultsProperty(): array
    {
        $term = trim($this->q);

        if ($term === '') {
            return [];
        }

        return products::where('status', 1)
            ->whereHas('segments')
            ->where(function ($query) use ($term) {
                $query->where('name', 'like', "%{$term}%")
                    ->orWhereHas('segments', fn ($q) => $q->where('name', 'like', "%{$term}%"));
            })
            ->with('segments')
            ->limit(8)
            ->get()
            ->map(fn (products $p) => [
                'name' => $p->name,
                'cat' => $p->segment?->name ?? '',
                'price' => (float) $p->price,
                'sale' => $p->discount_price !== null ? (float) $p->discounted_price : null,
                'inStock' => $p->stock_status === 'in_stock',
                'img' => $p->featured_image,
                'url' => $p->url,
            ])
            ->all();
    }

    public function render()
    {
        return view('livewire.ecomx-fashion.search-modal');
    }
}
