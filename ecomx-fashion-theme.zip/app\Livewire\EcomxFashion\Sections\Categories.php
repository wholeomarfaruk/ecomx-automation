<?php

namespace App\Livewire\EcomxFashion\Sections;

use App\Models\Category;
use Livewire\Attributes\Lazy;
use Livewire\Component;

#[Lazy]
class Categories extends Component
{
    public function placeholder()
    {
        return view('ecomx-fashion.livewire.sections.skeletons.categories');
    }

    public function render()
    {
        $categories = Category::where('is_homepage_show', true)
            ->where('is_active', true)
            ->with('banner')
            ->withCount('products')
            ->orderBy('display_order')
            ->orderBy('name')
            ->get()
            ->map(fn (Category $c) => [
                'name' => $c->name,
                'slug' => $c->slug,
                'count' => $c->products_count . ' ' . ($c->products_count === 1 ? 'piece' : 'pieces'),
                'image' => $c->banner?->getUrl()
                    ?? ($c->image ? asset('images/category/' . $c->image) : null),
            ]);

        return view('ecomx-fashion.livewire.sections.categories', [
            'categories' => $categories,
        ]);
    }
}
