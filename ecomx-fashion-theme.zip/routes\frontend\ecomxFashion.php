<?php

use Illuminate\Support\Facades\Route;

/**
 * ecomxFashion engine — storefront routes.
 *
 * Owns WHAT the ecomxFashion storefront does. Route names are stable
 * (ecomx-fashion.*) across every theme this engine has.
 *
 * Loaded once per request by EngineManager::loadActiveThemeRoute(), called
 * from routes/web.php — never require this file directly.
 */
Route::prefix('ecomx-fashion')->name('ecomx-fashion.')->group(function () {
    Route::get('/', \App\Livewire\EcomxFashion\Home::class)->name('home');
    Route::get('/shop', \App\Livewire\EcomxFashion\Shop::class)->name('shop');
    Route::get('/category/{slug?}', \App\Livewire\EcomxFashion\Category::class)->name('category');
    Route::get('/product/{slug?}', \App\Livewire\EcomxFashion\Product::class)->name('product');
    Route::get('/reviews', \App\Livewire\EcomxFashion\Reviews::class)->name('reviews');
    Route::get('/track', \App\Livewire\EcomxFashion\Track::class)->name('track');
    Route::get('/checkout', \App\Livewire\EcomxFashion\Checkout::class)->name('checkout');
});
