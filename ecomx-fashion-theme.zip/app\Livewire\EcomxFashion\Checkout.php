<?php

namespace App\Livewire\EcomxFashion;

use App\Models\Cart;
use App\Models\Device;
use Livewire\Component;
use Livewire\Attributes\Layout;

#[Layout('ecomx-fashion.layouts.ecomx_fashion')]
class Checkout extends Component
{
    public string $name = '';
    public string $phone = '';
    public string $address = '';
    public string $note = '';
    public string $delivery_area = 'dhaka';
    public string $payment_method = 'cod';
    public string $transaction_id = '';

    public bool $placed = false;

    public array $deliveryAreas = [
        ['id' => 'dhaka', 'name' => 'Inside Dhaka', 'charge' => 70],
        ['id' => 'outside', 'name' => 'Outside Dhaka', 'charge' => 130],
    ];

    public string $bkashNumber = '01682963493';

    protected function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:20',
            'address' => 'required|string',
            'delivery_area' => 'required|in:dhaka,outside',
            'payment_method' => 'required|in:cod,bkash',
            'transaction_id' => 'required_if:payment_method,bkash|nullable|string|max:100',
        ];
    }

    public function placeOrder(): void
    {
        $this->validate();

        $this->placed = true;
    }

    public function getCartProperty(): Cart
    {
        $device = Device::where('device_id', request()->cookie('_sfdid'))->first();

        $cart = Cart::firstOrCreate(
            ['customer_id' => null, 'device_id' => $device?->id],
            []
        );

        $cart->load('items.product', 'items.variant.values.attribute');

        return $cart;
    }

    public function render()
    {
        return view('ecomx-fashion.livewire.checkout', [
            'cart' => $this->cart,
        ]);
    }
}
