<section class="container section" aria-label="Trending collection loading">
    <div class="skel skel--text" style="width:240px;height:26px;margin-bottom:24px"></div>
    <div class="row-scroll no-scrollbar" style="gap:18px">
        @for($i = 0; $i < 5; $i++)
            <div class="skel" style="flex:none;width:calc((100% - 72px)/5);min-width:180px;aspect-ratio:3/4"></div>
        @endfor
    </div>
</section>
