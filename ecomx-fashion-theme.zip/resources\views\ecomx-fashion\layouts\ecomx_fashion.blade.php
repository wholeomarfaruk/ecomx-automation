<!DOCTYPE html>
<html lang="en" data-pal="{{ \App\Support\EcomxFashion\PaletteRegistry::active() }}" x-data>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? 'Seldom Fashion — Premium clothing, made in Bangladesh' }}</title>
    <meta name="description" content="Considered clothing, made rarely and made well. Designed in Dhaka, Bangladesh.">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;1,400&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    @vite(['resources/ecomx-fashion/scss/app.scss', 'resources/ecomx-fashion/js/app.js'])
    @livewireStyles

    {{-- Google Tag Manager — same GTM container as the legacy website theme
         (layouts/website.blade.php), ported as-is; that file is untouched. --}}
    @if (app()->environment('production'))
        <script>
            (function(w, d, s, l, i) {
                w[l] = w[l] || [];
                w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
                var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
                j.async = true;
                j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
                f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-5XWHPZQH');
        </script>
    @endif
</head>
<body>
    @if (app()->environment('production'))
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5XWHPZQH" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    @endif

    @include('ecomx-fashion.partials.header')

    <main>
        {{ $slot }}
    </main>

    @include('ecomx-fashion.partials.footer')
    @include('ecomx-fashion.partials.bottom-nav')
    @include('ecomx-fashion.partials.support-modal')
    @include('ecomx-fashion.partials.auth-modal')
    @livewire('ecomx-fashion.cart-manager')
    @livewire('ecomx-fashion.search-modal')
    @livewire('ecomx-fashion.wishlist-drawer')

    {{-- PageView tracking — dataLayer push + (in debugmode) Meta CAPI relay,
         ported from the legacy website theme's same block. Uses the
         App\CAPI\PageViewEvent class as-is (untouched) and the existing
         /fb-pixel-capi route. ecomx-fashion has no device-registration form
         flow, so user_data stays anonymous (null fields) rather than pulling
         from the legacy theme's `_sfud` cookie. --}}
    <script>
        (function() {
            var currentUrl = "{{ url()->current() }}";
            var referrerUrl = "{{ url()->previous() }}";
            var eventId = Date.now() + '_' + Math.random().toString(36).substring(2, 9);
            var deviceId = document.cookie.split(';').map(function(c) { return c.trim(); })
                .find(function(c) { return c.startsWith('_sfdid='); })?.split('=')[1];

            var pageViewDataSet = {
                XSRF_TOKEN: "{{ csrf_token() }}",
                event: 'PageView',
                event_id: eventId,
                event_source_url: currentUrl,
                referrer_url: referrerUrl,
                ecommerce: null,
                user_data: {
                    first_name: null,
                    last_name: null,
                    phone_number: null,
                    street: null,
                    country: "BD",
                    state: null,
                    city: null,
                    zipcode: null,
                    customer_id: deviceId || null,
                    client_ip_address: "{{ request()->ip() }}",
                    client_user_agent: navigator.userAgent,
                    fbc: null,
                },
            };

            window.dataLayer = window.dataLayer || [];
            window.dataLayer.push(pageViewDataSet);

            @if (session('debugmode'))
                @php
                    $pageViewEvent = new \App\CAPI\PageViewEvent();
                    $pageViewPayload = $pageViewEvent->browserEventPayload();
                @endphp
                var pageViewServer = @json($pageViewPayload);
                if (pageViewServer) {
                    window.dataLayer.push(pageViewServer);
                }
                fetch("{{ route('pixel.capi.track') }}?event_name=page_view", {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': "{{ csrf_token() }}",
                        },
                        body: JSON.stringify(pageViewDataSet),
                    })
                    .catch(function(error) {
                        console.error('Error tracking Facebook Pixel PageView:', error);
                    });
            @endif
        })();
    </script>

    @livewireScripts
</body>
</html>
