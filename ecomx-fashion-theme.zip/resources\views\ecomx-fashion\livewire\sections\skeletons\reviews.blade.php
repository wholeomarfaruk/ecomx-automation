<section class="container section" aria-label="Customer reviews loading">
    <div class="skel skel--text" style="width:260px;height:22px;margin-bottom:20px"></div>
    <div class="row-scroll no-scrollbar" style="gap:20px">
        @for($i = 0; $i < 4; $i++)
            <div class="skel" style="flex:none;width:280px;aspect-ratio:3/4;border-radius:14px"></div>
        @endfor
    </div>
</section>
