@extends('layouts.admin')
@section('content')
    <div class="main-content-inner">
        <div class="main-content-wrap">
            <div class="d-flex align-items-center flex-wrap justify-content-between gap-3 mb-4">
                <h3>{{ $meta['label'] ?? ucfirst($page) }}</h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.frontend.menu') }}">Frontend</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{ $meta['label'] ?? ucfirst($page) }}</li>
                    </ol>
                </nav>
            </div>

            <div class="card">
                <div class="card-body">
                    <p class="mb-4">
                        Toggle sections active/inactive and drag to reorder how they render on the storefront.
                    </p>

                    @livewire('admin.theme-engine.page-section-manager', ['page' => $page])
                </div>
            </div>
        </div>
    </div>

    @livewire('admin.theme-engine.section-config-editor')
    @livewire('admin.media.media-picker')
@endsection
