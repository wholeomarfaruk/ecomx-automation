@extends('layouts.admin')
@section('content')
    <div class="main-content-inner">
        <div class="main-content-wrap">
            <div class="d-flex align-items-center flex-wrap justify-content-between gap-3 mb-4">
                <h3>Appearance</h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.frontend.menu') }}">Frontend</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Appearance</li>
                    </ol>
                </nav>
            </div>

            <div class="card">
                <div class="card-body">
                    @livewire('admin.theme-engine.palette-manager')
                </div>
            </div>
        </div>
    </div>
@endsection
