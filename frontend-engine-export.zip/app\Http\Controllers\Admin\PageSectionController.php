<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

class PageSectionController extends Controller
{
    public function index()
    {
        return view('admin.theme-engine.page-sections');
    }
}
