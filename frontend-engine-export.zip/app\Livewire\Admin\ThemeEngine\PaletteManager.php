<?php

namespace App\Livewire\Admin\ThemeEngine;

use App\Support\EcomxFashion\PaletteRegistry;
use Livewire\Component;

class PaletteManager extends Component
{
    public function activate(string $palette): void
    {
        PaletteRegistry::setActive($palette);

        $this->dispatch('toast', [
            'title'   => 'Success',
            'message' => ucfirst($palette) . ' is now the active palette.',
            'icon'    => 'success',
        ]);
    }

    public function render()
    {
        return view('livewire.admin.theme-engine.palette-manager', [
            'palettes' => config('ecomx-fashion.palettes', []),
            'swatches' => PaletteRegistry::swatches(),
            'active'   => PaletteRegistry::active(),
        ]);
    }
}
