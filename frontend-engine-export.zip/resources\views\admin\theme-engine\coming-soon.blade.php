@extends('layouts.admin')
@section('content')
    <div class="main-content-inner">
        <div class="main-content-wrap">
            <div class="d-flex align-items-center flex-wrap justify-content-between gap-3 mb-4">
                <h3>{{ $title }}</h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('admin.frontend.menu') }}">Frontend</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{ $title }}</li>
                    </ol>
                </nav>
            </div>

            <div class="card">
                <div class="card-body text-center py-5">
                    <i class="icon-clock fs-1 text-muted mb-3 d-block"></i>
                    <h5 class="mb-2">Coming soon</h5>
                    <p class="text-muted mb-0">{{ $description }}</p>
                </div>
            </div>
        </div>
    </div>
@endsection
