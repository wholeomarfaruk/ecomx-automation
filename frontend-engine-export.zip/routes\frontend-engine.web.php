<?php

// Extracted from routes/web.php (lines 141-150)
// These routes were originally registered inside the 'admin' route group/prefix/middleware.
// Paste back into that group in routes/web.php — do not register standalone.

// Theme Engine — page sections (active/inactive + reorder)
Route::get('/theme-engine/page-sections', [\App\Http\Controllers\Admin\PageSectionController::class, 'index'])->name('admin.theme-engine.page-sections');

// Frontend Menu — registered pages of the active theme + per-page section settings
Route::get('/frontend', [\App\Http\Controllers\Admin\PageMenuController::class, 'index'])->name('admin.frontend.menu');
Route::get('/frontend/appearance', [\App\Http\Controllers\Admin\PageMenuController::class, 'appearance'])->name('admin.frontend.appearance');
Route::get('/frontend/themes', [\App\Http\Controllers\Admin\PageMenuController::class, 'themes'])->name('admin.frontend.themes');
Route::get('/frontend/menus', [\App\Http\Controllers\Admin\PageMenuController::class, 'menus'])->name('admin.frontend.menus');
Route::get('/frontend/components', [\App\Http\Controllers\Admin\PageMenuController::class, 'components'])->name('admin.frontend.components');
Route::get('/frontend/{page}', [\App\Http\Controllers\Admin\PageMenuController::class, 'show'])->name('admin.frontend.menu.show');
