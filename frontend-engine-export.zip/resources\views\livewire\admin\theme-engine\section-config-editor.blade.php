<div x-data="{ open: @entangle('isOpen').live }" x-cloak>
    <div
        x-show="open"
        x-transition:enter="fade" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
        x-transition:leave="fade" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
        class="modal-backdrop show"
        @click="$wire.close()"
    ></div>

    <div
        x-show="open"
        :class="open ? 'd-block' : 'd-none'"
        class="modal"
        tabindex="-1"
        style="z-index:1050 !important;"
    >
        <div class="modal-dialog modal-fullscreen modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title mb-0">
                        Configure — {{ ucwords(str_replace('-', ' ', $section)) }}
                    </h5>
                    <button type="button" class="btn-close" wire:click="close"></button>
                </div>

                <div class="modal-body">
                    @if (empty($this->fields()))
                        <div class="text-center py-5">
                            <p class="mb-0">No configurable fields for this section yet.</p>
                        </div>
                    @else
                        @foreach ($this->fields() as $field)
                            <div class="mb-5">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <h6 class="mb-0">{{ $field['label'] }}</h6>
                                    @if ($field['type'] === 'media_list')
                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                                wire:click="addMediaSlot('{{ $field['key'] }}')">
                                            <i class="icon-plus"></i> Add Image
                                        </button>
                                    @elseif ($field['type'] === 'text_list')
                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                                wire:click="addTextItem('{{ $field['key'] }}')">
                                            <i class="icon-plus"></i> Add Item
                                        </button>
                                    @elseif ($field['type'] === 'faq_list')
                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                                wire:click="addFaqItem('{{ $field['key'] }}')">
                                            <i class="icon-plus"></i> Add FAQ
                                        </button>
                                    @elseif ($field['type'] === 'stat_list')
                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                                wire:click="addStatItem('{{ $field['key'] }}')">
                                            <i class="icon-plus"></i> Add Stat
                                        </button>
                                    @endif
                                </div>

                                @if ($field['type'] === 'category_list')
                                    <p class="text-muted small mb-3">
                                        Toggle categories on to show them in this section. Drag to set the order they appear in.
                                    </p>
                                @elseif ($field['type'] === 'category_multi_select')
                                    <p class="text-muted small mb-3">
                                        Pick up to {{ $field['max'] ?? count($categories) }} categories
                                        ({{ count($values[$field['key']] ?? []) }}/{{ $field['max'] ?? count($categories) }} selected).
                                    </p>
                                @endif

                                @if ($field['type'] === 'text')
                                    <input type="text" class="form-control"
                                           placeholder="{{ $field['placeholder'] ?? '' }}"
                                           value="{{ $values[$field['key']] ?? '' }}"
                                           onchange="@this.call('updateText', '{{ $field['key'] }}', this.value)">
                                @elseif ($field['type'] === 'category_select')
                                    <select class="form-select"
                                            onchange="@this.call('updateCategorySelect', '{{ $field['key'] }}', this.value)">
                                        <option value="">— None (use demo products) —</option>
                                        @foreach ($categories as $cat)
                                            <option value="{{ $cat['id'] }}" {{ (string) ($values[$field['key']] ?? '') === (string) $cat['id'] ? 'selected' : '' }}>
                                                {{ $cat['name'] }}
                                            </option>
                                        @endforeach
                                    </select>
                                @elseif ($field['type'] === 'category_multi_select')
                                    @php $selected = $values[$field['key']] ?? []; @endphp
                                    <div class="row g-2">
                                        @forelse ($categories as $cat)
                                            @php $isChecked = in_array($cat['id'], $selected, true); @endphp
                                            <div class="col-md-4 col-sm-6">
                                                <label class="d-flex align-items-center gap-2 border rounded p-2 mb-0 {{ $isChecked ? 'border-primary' : '' }}">
                                                    <input type="checkbox" class="form-check-input mt-0"
                                                           {{ $isChecked ? 'checked' : '' }}
                                                           {{ (! $isChecked && isset($field['max']) && count($selected) >= $field['max']) ? 'disabled' : '' }}
                                                           onchange="@this.call('toggleCategoryMultiSelect', '{{ $field['key'] }}', {{ $cat['id'] }}, this.checked)">
                                                    <span>{{ $cat['name'] }}</span>
                                                </label>
                                            </div>
                                        @empty
                                            <div class="col-12">
                                                <p class="text-muted mb-0">No active categories found.</p>
                                            </div>
                                        @endforelse
                                    </div>
                                @elseif ($field['type'] === 'media_list')
                                    <div class="row g-3">
                                        @forelse ($values[$field['key']] ?? [] as $i => $item)
                                            <div class="col-md-3 col-sm-4 col-6" wire:key="{{ $field['key'] }}-{{ $item['id'] }}">
                                                <div class="position-relative mb-2">
                                                    <img src="{{ $item['thumbnail'] ?? $item['url'] }}" class="w-100 rounded" style="aspect-ratio:1;object-fit:cover">
                                                    <button type="button"
                                                            class="btn btn-sm btn-danger position-absolute top-0 end-0 m-1"
                                                            wire:click="removeMediaItem('{{ $field['key'] }}', {{ $i }})">
                                                        <i class="icon-x"></i>
                                                    </button>
                                                </div>
                                                <input type="text" class="form-control form-control-sm"
                                                       placeholder="Link (optional)"
                                                       value="{{ $item['link'] ?? '' }}"
                                                       onchange="@this.call('updateMediaLink', '{{ $field['key'] }}', {{ $i }}, this.value)">
                                            </div>
                                        @empty
                                            <div class="col-12">
                                                <p class="text-muted mb-0">No images added yet.</p>
                                            </div>
                                        @endforelse
                                    </div>
                                @elseif ($field['type'] === 'text_list')
                                    @if (empty($values[$field['key']] ?? []))
                                        <p class="text-muted mb-0">No items added yet.</p>
                                    @else
                                        <div class="text-list-sortable" data-field="{{ $field['key'] }}" wire:ignore.self>
                                            @foreach ($values[$field['key']] as $i => $item)
                                                <div class="input-group mb-2" wire:key="{{ $field['key'] }}-item-{{ $i }}" data-index="{{ $i }}">
                                                    <span class="input-group-text text-list-drag-handle" style="cursor:grab">
                                                        <i class="icon-menu"></i>
                                                    </span>
                                                    <input type="text" class="form-control"
                                                           value="{{ $item['text'] ?? '' }}"
                                                           onchange="@this.call('updateTextItem', '{{ $field['key'] }}', {{ $i }}, this.value)">
                                                    <button type="button" class="btn btn-outline-danger"
                                                            wire:click="removeTextItem('{{ $field['key'] }}', {{ $i }})">
                                                        <i class="icon-x"></i>
                                                    </button>
                                                </div>
                                            @endforeach
                                        </div>
                                    @endif
                                @elseif ($field['type'] === 'faq_list')
                                    @if (empty($values[$field['key']] ?? []))
                                        <p class="text-muted mb-0">No FAQs added yet.</p>
                                    @else
                                        <div class="faq-list-sortable" data-field="{{ $field['key'] }}" wire:ignore.self>
                                            @foreach ($values[$field['key']] as $i => $item)
                                                <div class="d-flex align-items-start gap-2 mb-2" wire:key="{{ $field['key'] }}-faq-{{ $i }}" data-index="{{ $i }}">
                                                    <span class="input-group-text faq-list-drag-handle" style="cursor:grab">
                                                        <i class="icon-menu"></i>
                                                    </span>
                                                    <div class="flex-grow-1">
                                                        <input type="text" class="form-control mb-2"
                                                               placeholder="Question"
                                                               value="{{ $item['q'] ?? '' }}"
                                                               onchange="@this.call('updateFaqItem', '{{ $field['key'] }}', {{ $i }}, 'q', this.value)">
                                                        <textarea class="form-control" rows="2" placeholder="Answer"
                                                                  onchange="@this.call('updateFaqItem', '{{ $field['key'] }}', {{ $i }}, 'a', this.value)">{{ $item['a'] ?? '' }}</textarea>
                                                    </div>
                                                    <button type="button" class="btn btn-outline-danger"
                                                            wire:click="removeFaqItem('{{ $field['key'] }}', {{ $i }})">
                                                        <i class="icon-x"></i>
                                                    </button>
                                                </div>
                                            @endforeach
                                        </div>
                                    @endif
                                @elseif ($field['type'] === 'stat_list')
                                    @if (empty($values[$field['key']] ?? []))
                                        <p class="text-muted mb-0">No stats added yet.</p>
                                    @else
                                        <div class="stat-list-sortable" data-field="{{ $field['key'] }}" wire:ignore.self>
                                            @foreach ($values[$field['key']] as $i => $item)
                                                <div class="input-group mb-2" wire:key="{{ $field['key'] }}-stat-{{ $i }}" data-index="{{ $i }}">
                                                    <span class="input-group-text stat-list-drag-handle" style="cursor:grab">
                                                        <i class="icon-menu"></i>
                                                    </span>
                                                    <input type="text" class="form-control"
                                                           placeholder="Value (e.g. 40,000+)"
                                                           value="{{ $item['val'] ?? '' }}"
                                                           onchange="@this.call('updateStatItem', '{{ $field['key'] }}', {{ $i }}, 'val', this.value)">
                                                    <input type="text" class="form-control"
                                                           placeholder="Label (e.g. Happy customers)"
                                                           value="{{ $item['label'] ?? '' }}"
                                                           onchange="@this.call('updateStatItem', '{{ $field['key'] }}', {{ $i }}, 'label', this.value)">
                                                    <button type="button" class="btn btn-outline-danger"
                                                            wire:click="removeStatItem('{{ $field['key'] }}', {{ $i }})">
                                                        <i class="icon-x"></i>
                                                    </button>
                                                </div>
                                            @endforeach
                                        </div>
                                    @endif
                                @elseif ($field['type'] === 'category_list')
                                    @if (empty($categories))
                                        <p class="text-muted mb-0">No active categories found.</p>
                                    @else
                                        <div class="category-list-sortable" wire:ignore.self>
                                            @foreach ($categories as $cat)
                                                <div class="d-flex align-items-center gap-3 border rounded p-2 mb-2" wire:key="category-{{ $cat['id'] }}" data-id="{{ $cat['id'] }}">
                                                    <span class="category-drag-handle" style="cursor:grab">
                                                        <i class="icon-menu"></i>
                                                    </span>
                                                    <div class="text-center">
                                                        @if ($cat['image'])
                                                            <img src="{{ asset('images/category/' . $cat['image']) }}" class="rounded" style="width:48px;height:48px;object-fit:cover">
                                                        @else
                                                            <div class="d-flex align-items-center justify-content-center bg-light rounded" style="width:48px;height:48px;">
                                                                <i class="icon-image text-muted"></i>
                                                            </div>
                                                        @endif
                                                        <div class="text-muted" style="font-size:11px">Featured</div>
                                                    </div>
                                                    <div class="text-center">
                                                        @if ($cat['banner_thumbnail'])
                                                            <img src="{{ $cat['banner_thumbnail'] }}" class="rounded" style="width:48px;height:48px;object-fit:cover">
                                                        @else
                                                            <div class="d-flex align-items-center justify-content-center bg-light rounded" style="width:48px;height:48px;">
                                                                <i class="icon-image text-muted"></i>
                                                            </div>
                                                        @endif
                                                        <div class="text-muted" style="font-size:11px">Banner</div>
                                                    </div>
                                                    <div class="flex-grow-1">
                                                        {{ $cat['name'] }}
                                                        <button type="button" class="btn btn-sm btn-link p-0 d-block"
                                                                wire:click="pickCategoryBanner({{ $cat['id'] }})">
                                                            Set banner image
                                                        </button>
                                                    </div>
                                                    <div class="form-check form-switch mb-0" wire:key="cat-switch-{{ $cat['id'] }}-{{ $cat['is_homepage_show'] ? '1' : '0' }}">
                                                        <input type="checkbox" class="form-check-input" role="switch"
                                                               {{ $cat['is_homepage_show'] ? 'checked' : '' }}
                                                               onchange="@this.call('toggleCategoryHomepage', {{ $cat['id'] }}, this.checked)">
                                                        <span class="badge {{ $cat['is_homepage_show'] ? 'bg-success' : 'bg-secondary' }}">{{ $cat['is_homepage_show'] ? 'Shown' : 'Hidden' }}</span>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                    @endif
                                @endif
                            </div>
                        @endforeach
                    @endif
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" wire:click="close">Close</button>
                    @if (collect($this->fields())->contains(fn ($f) => $f['type'] !== 'category_list'))
                        <button type="button" class="btn btn-primary" wire:click="save">Save Changes</button>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js"></script>
<script>
document.addEventListener('livewire:init', () => {
    const initSortables = () => {
        document.querySelectorAll('.text-list-sortable').forEach((el) => {
            if (el.dataset.sortableInit) return;
            el.dataset.sortableInit = '1';

            new Sortable(el, {
                handle: '.text-list-drag-handle',
                animation: 150,
                onEnd: () => {
                    const indexes = Array.from(el.querySelectorAll('[data-index]')).map(row => parseInt(row.dataset.index, 10));
                    const root = el.closest('[wire\\:id]');
                    const component = Livewire.find(root.getAttribute('wire:id'));
                    component.call('reorderTextItems', el.dataset.field, indexes);
                },
            });
        });

        document.querySelectorAll('.category-list-sortable').forEach((el) => {
            if (el.dataset.sortableInit) return;
            el.dataset.sortableInit = '1';

            new Sortable(el, {
                handle: '.category-drag-handle',
                animation: 150,
                onEnd: () => {
                    const ids = Array.from(el.querySelectorAll('[data-id]')).map(row => parseInt(row.dataset.id, 10));
                    const root = el.closest('[wire\\:id]');
                    const component = Livewire.find(root.getAttribute('wire:id'));
                    component.call('reorderCategories', ids);
                },
            });
        });

        document.querySelectorAll('.faq-list-sortable').forEach((el) => {
            if (el.dataset.sortableInit) return;
            el.dataset.sortableInit = '1';

            new Sortable(el, {
                handle: '.faq-list-drag-handle',
                animation: 150,
                onEnd: () => {
                    const indexes = Array.from(el.querySelectorAll('[data-index]')).map(row => parseInt(row.dataset.index, 10));
                    const root = el.closest('[wire\\:id]');
                    const component = Livewire.find(root.getAttribute('wire:id'));
                    component.call('reorderFaqItems', el.dataset.field, indexes);
                },
            });
        });

        document.querySelectorAll('.stat-list-sortable').forEach((el) => {
            if (el.dataset.sortableInit) return;
            el.dataset.sortableInit = '1';

            new Sortable(el, {
                handle: '.stat-list-drag-handle',
                animation: 150,
                onEnd: () => {
                    const indexes = Array.from(el.querySelectorAll('[data-index]')).map(row => parseInt(row.dataset.index, 10));
                    const root = el.closest('[wire\\:id]');
                    const component = Livewire.find(root.getAttribute('wire:id'));
                    component.call('reorderStatItems', el.dataset.field, indexes);
                },
            });
        });
    };

    initSortables();
    Livewire.hook('morph.updated', () => {
        document.querySelectorAll('.text-list-sortable, .category-list-sortable, .faq-list-sortable, .stat-list-sortable').forEach((el) => delete el.dataset.sortableInit);
        initSortables();
    });
});
</script>
@endpush
