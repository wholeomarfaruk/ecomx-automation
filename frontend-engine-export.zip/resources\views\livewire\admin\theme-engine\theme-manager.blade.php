<div>
    <p class="mb-4">
        Installed theme packages. Activating a theme switches the entire storefront (pages, sections, layouts) to it.
    </p>

    <div class="row g-3">
        @foreach ($themes as $slug => $meta)
            <div class="col-md-4">
                <div class="card h-100 {{ $active === $slug ? 'border-primary' : '' }}">
                    @if ($meta['cover'])
                        <img src="{{ $meta['cover'] }}" alt="{{ $meta['name'] }}" class="card-img-top" style="height:160px;object-fit:cover">
                    @endif
                    <div class="card-body">
                        <div class="d-flex align-items-start justify-content-between mb-2">
                            <div class="fw-semibold">{{ $meta['name'] }}</div>
                            @if ($active === $slug)
                                <span class="badge bg-success">Active</span>
                            @endif
                        </div>
                        @if ($meta['description'])
                            <p class="text-muted small mb-3">{{ $meta['description'] }}</p>
                        @endif
                        @if ($meta['version'])
                            <p class="text-muted small mb-3">v{{ $meta['version'] }}</p>
                        @endif
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary"
                                    wire:click="validate_('{{ $slug }}')"
                                    wire:loading.attr="disabled">
                                Validate
                            </button>
                            @if ($active !== $slug)
                                <button type="button" class="btn btn-sm btn-outline-primary"
                                        wire:click="activate('{{ $slug }}')"
                                        wire:loading.attr="disabled"
                                        wire:confirm="Switch the live storefront to {{ $meta['name'] }}?">
                                    Activate
                                </button>
                            @endif
                        </div>

                        @if ($reportSlug === $slug && $report)
                            <div class="mt-3 small">
                                <div class="fw-semibold mb-1 {{ $report->passed() ? 'text-success' : 'text-danger' }}">
                                    {{ $report->passed() ? 'READY' : 'NOT READY' }}
                                </div>
                                @foreach ($report->grouped() as $group => $checks)
                                    @foreach ($checks as $check)
                                        <div class="{{ $check['ok'] ? 'text-success' : 'text-danger' }}">
                                            {{ $check['ok'] ? '✓' : '✗' }} {{ $check['label'] }}
                                            @if (! $check['ok'] && $check['detail'])
                                                <span class="text-muted">— {{ $check['detail'] }}</span>
                                            @endif
                                        </div>
                                    @endforeach
                                @endforeach
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach

        @if (empty($themes))
            <div class="col-12">
                <p class="text-muted mb-0">No theme packages found under resources/*/theme.json.</p>
            </div>
        @endif
    </div>
</div>
