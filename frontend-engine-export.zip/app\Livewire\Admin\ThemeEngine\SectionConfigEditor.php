<?php

namespace App\Livewire\Admin\ThemeEngine;

use App\Models\Category;
use App\Support\EcomxFashion\PageSectionConfigRegistry;
use App\Support\EcomxFashion\SectionSchema;
use Livewire\Attributes\On;
use Livewire\Component;

class SectionConfigEditor extends Component
{
    public bool $isOpen = false;
    public string $page = '';
    public string $section = '';

    /** @var array<string, array> field key => list of ['id','url','thumbnail'] media items */
    public array $values = [];

    /** @var array<int, array{id:int,name:string,image:?string,banner_thumbnail:?string,is_homepage_show:bool}> Loaded for 'category_list' fields only. */
    public array $categories = [];

    #[On('open-section-config-editor')]
    public function open(string $page, string $section): void
    {
        $this->page = $page;
        $this->section = $section;

        $saved = PageSectionConfigRegistry::find($page, $section);
        $defaults = SectionSchema::defaultsFor($section);
        $this->values = array_merge($defaults, $saved ?? []);

        if ($this->needsCategories()) {
            $this->loadCategories();
        }

        $this->isOpen = true;
    }

    protected function needsCategories(): bool
    {
        return collect(SectionSchema::fieldsFor($this->section))
            ->contains(fn (array $field) => in_array($field['type'], ['category_list', 'category_select', 'category_multi_select'], true));
    }

    protected function loadCategories(): void
    {
        $this->categories = Category::where('is_active', true)
            ->with('banner')
            ->orderBy('display_order')
            ->orderBy('name')
            ->get(['id', 'name', 'image', 'banner_media_id', 'is_homepage_show', 'display_order'])
            ->map(fn (Category $c) => [
                'id' => $c->id,
                'name' => $c->name,
                'image' => $c->image,
                'banner_thumbnail' => $c->banner?->getThumbnailUrl(),
                'is_homepage_show' => (bool) $c->is_homepage_show,
            ])
            ->toArray();
    }

    public function toggleCategoryHomepage(int $categoryId, bool $value): void
    {
        Category::whereKey($categoryId)->update(['is_homepage_show' => $value]);
        $this->loadCategories();

        $this->dispatch('toast', [
            'title'   => 'Success',
            'message' => 'Category ' . ($value ? 'shown' : 'hidden') . ' on homepage.',
            'icon'    => 'success',
        ]);
    }

    public function pickCategoryBanner(int $categoryId): void
    {
        $this->dispatch('open-media-picker', multiple: false, callbackKey: "category-banner:{$categoryId}");
    }

    /** @param int[] $orderedCategoryIds Category IDs in their new display order. */
    public function reorderCategories(array $orderedCategoryIds): void
    {
        foreach ($orderedCategoryIds as $order => $categoryId) {
            Category::whereKey($categoryId)->update(['display_order' => $order]);
        }

        $this->loadCategories();

        $this->dispatch('toast', [
            'title'   => 'Success',
            'message' => 'Category order updated.',
            'icon'    => 'success',
        ]);
    }

    public function close(): void
    {
        $this->isOpen = false;
    }

    public function fields(): array
    {
        return SectionSchema::fieldsFor($this->section);
    }

    public function addMediaSlot(string $fieldKey): void
    {
        $this->dispatch('open-media-picker', multiple: false, callbackKey: "section-config:{$fieldKey}");
    }

    public function removeMediaItem(string $fieldKey, int $index): void
    {
        unset($this->values[$fieldKey][$index]);
        $this->values[$fieldKey] = array_values($this->values[$fieldKey]);
    }

    public function updateMediaLink(string $fieldKey, int $index, string $link): void
    {
        $this->values[$fieldKey][$index]['link'] = $link;
    }

    public function updateText(string $fieldKey, string $value): void
    {
        $this->values[$fieldKey] = $value;
    }

    public function updateCategorySelect(string $fieldKey, string $categoryId): void
    {
        $this->values[$fieldKey] = $categoryId;
    }

    public function toggleCategoryMultiSelect(string $fieldKey, int $categoryId, bool $checked): void
    {
        $selected = $this->values[$fieldKey] ?? [];

        if ($checked) {
            $max = collect(SectionSchema::fieldsFor($this->section))
                ->firstWhere('key', $fieldKey)['max'] ?? null;

            if ($max !== null && count($selected) >= $max) {
                return;
            }

            if (! in_array($categoryId, $selected, true)) {
                $selected[] = $categoryId;
            }
        } else {
            $selected = array_values(array_diff($selected, [$categoryId]));
        }

        $this->values[$fieldKey] = $selected;
    }

    public function addTextItem(string $fieldKey): void
    {
        $this->values[$fieldKey][] = ['text' => ''];
    }

    public function updateTextItem(string $fieldKey, int $index, string $text): void
    {
        $this->values[$fieldKey][$index]['text'] = $text;
    }

    public function removeTextItem(string $fieldKey, int $index): void
    {
        unset($this->values[$fieldKey][$index]);
        $this->values[$fieldKey] = array_values($this->values[$fieldKey]);
    }

    /** @param int[] $orderedIndexes Current indexes of $values[$fieldKey], in their new order. */
    public function reorderTextItems(string $fieldKey, array $orderedIndexes): void
    {
        $this->values[$fieldKey] = array_values(array_map(
            fn (int $i) => $this->values[$fieldKey][$i],
            $orderedIndexes
        ));
    }

    public function addFaqItem(string $fieldKey): void
    {
        $this->values[$fieldKey][] = ['q' => '', 'a' => ''];
    }

    public function updateFaqItem(string $fieldKey, int $index, string $part, string $value): void
    {
        $this->values[$fieldKey][$index][$part] = $value;
    }

    public function removeFaqItem(string $fieldKey, int $index): void
    {
        unset($this->values[$fieldKey][$index]);
        $this->values[$fieldKey] = array_values($this->values[$fieldKey]);
    }

    /** @param int[] $orderedIndexes Current indexes of $values[$fieldKey], in their new order. */
    public function reorderFaqItems(string $fieldKey, array $orderedIndexes): void
    {
        $this->values[$fieldKey] = array_values(array_map(
            fn (int $i) => $this->values[$fieldKey][$i],
            $orderedIndexes
        ));
    }

    public function addStatItem(string $fieldKey): void
    {
        $this->values[$fieldKey][] = ['val' => '', 'label' => ''];
    }

    public function updateStatItem(string $fieldKey, int $index, string $part, string $value): void
    {
        $this->values[$fieldKey][$index][$part] = $value;
    }

    public function removeStatItem(string $fieldKey, int $index): void
    {
        unset($this->values[$fieldKey][$index]);
        $this->values[$fieldKey] = array_values($this->values[$fieldKey]);
    }

    /** @param int[] $orderedIndexes Current indexes of $values[$fieldKey], in their new order. */
    public function reorderStatItems(string $fieldKey, array $orderedIndexes): void
    {
        $this->values[$fieldKey] = array_values(array_map(
            fn (int $i) => $this->values[$fieldKey][$i],
            $orderedIndexes
        ));
    }

    #[On('media-picker-confirmed')]
    public function onMediaPickerConfirmed(array $payload): void
    {
        $callbackKey = $payload['callbackKey'] ?? '';
        $single = $payload['single'] ?? null;

        if (! $single) {
            return;
        }

        if (str_starts_with($callbackKey, 'section-config:')) {
            $fieldKey = substr($callbackKey, strlen('section-config:'));

            $this->values[$fieldKey][] = [
                'id' => $single['id'],
                'url' => $single['url'],
                'thumbnail' => $single['thumbnail'],
                'link' => '',
            ];

            return;
        }

        if (str_starts_with($callbackKey, 'category-banner:')) {
            $categoryId = (int) substr($callbackKey, strlen('category-banner:'));

            Category::whereKey($categoryId)->update(['banner_media_id' => $single['id']]);
            $this->loadCategories();

            $this->dispatch('toast', [
                'title'   => 'Success',
                'message' => 'Banner image updated.',
                'icon'    => 'success',
            ]);
        }
    }

    public function save(): void
    {
        PageSectionConfigRegistry::save($this->page, $this->section, $this->values);

        $this->dispatch('toast', [
            'title'   => 'Success',
            'message' => 'Section configuration saved.',
            'icon'    => 'success',
        ]);

        $this->dispatch('section-config-saved');
        $this->isOpen = false;
    }

    public function render()
    {
        return view('livewire.admin.theme-engine.section-config-editor');
    }
}
