<div>
    <p class="mb-4">
        Pick the site-wide colour palette for the storefront. The active palette applies to every visitor immediately.
    </p>

    <div class="row g-3">
        @foreach ($palettes as $palette)
            @php $c = $swatches[$palette] ?? ['pri' => '#999', 'sec' => '#eee', 'ac' => '#999']; @endphp
            <div class="col-md-3 col-sm-4 col-6">
                <div class="card h-100 {{ $active === $palette ? 'border-primary' : '' }}">
                    <div class="card-body text-center">
                        <div class="d-flex justify-content-center mb-3" style="gap:6px">
                            <span style="display:block;width:28px;height:28px;border-radius:999px;background:{{ $c['pri'] }};border:1px solid rgba(0,0,0,.08)"></span>
                            <span style="display:block;width:28px;height:28px;border-radius:999px;background:{{ $c['sec'] }};border:1px solid rgba(0,0,0,.08)"></span>
                            <span style="display:block;width:28px;height:28px;border-radius:999px;background:{{ $c['ac'] }};border:1px solid rgba(0,0,0,.08)"></span>
                        </div>
                        <div class="fw-semibold mb-2">{{ ucfirst($palette) }}</div>
                        @if ($active === $palette)
                            <span class="badge bg-success">Active</span>
                        @else
                            <button type="button" class="btn btn-sm btn-outline-primary"
                                    wire:click="activate('{{ $palette }}')"
                                    wire:loading.attr="disabled">
                                Activate
                            </button>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
