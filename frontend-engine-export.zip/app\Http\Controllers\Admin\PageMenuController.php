<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Support\EcomxFashion\PageRegistry;

class PageMenuController extends Controller
{
    public function index()
    {
        return view('admin.theme-engine.menu-index', [
            'pages' => PageRegistry::all(),
        ]);
    }

    public function show(string $page)
    {
        abort_unless(PageRegistry::exists($page), 404);

        return view('admin.theme-engine.menu-show', [
            'page' => $page,
            'meta' => PageRegistry::find($page),
        ]);
    }

    public function appearance()
    {
        return view('admin.theme-engine.appearance');
    }

    public function themes()
    {
        return view('admin.theme-engine.themes');
    }

    public function menus()
    {
        return view('admin.theme-engine.coming-soon', [
            'title' => 'Menus',
            'description' => 'Header and footer navigation link management is planned but not built yet.',
        ]);
    }

    public function components()
    {
        return view('admin.theme-engine.coming-soon', [
            'title' => 'Components',
            'description' => 'Header, footer, and other reusable component settings are planned but not built yet.',
        ]);
    }
}
