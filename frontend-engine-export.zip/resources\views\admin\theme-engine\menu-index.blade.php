@extends('layouts.admin')
@section('content')
    <div class="main-content-inner">
        <div class="main-content-wrap">
            <div class="d-flex align-items-center flex-wrap justify-content-between gap-3 mb-4">
                <h3>Frontend</h3>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="{{ route('admin.index') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Frontend</li>
                    </ol>
                </nav>
            </div>

            <div class="card">
                <div class="card-body">
                    <p class="mb-4">
                        All registered pages for the active theme. Click a page to manage its sections.
                    </p>

                    <div class="row g-3">
                        @foreach ($pages as $key => $meta)
                            <div class="col-md-4">
                                <a href="{{ route('admin.frontend.menu.show', $key) }}"
                                   class="card text-decoration-none h-100">
                                    <div class="card-body d-flex align-items-center gap-3">
                                        <i class="{{ $meta['icon'] ?? 'icon-layers' }} fs-3"></i>
                                        <div>
                                            <div class="fw-semibold">{{ $meta['label'] ?? ucfirst($key) }}</div>
                                            <div class="small text-muted">
                                                @if (count($meta['sections'] ?? []) > 0)
                                                    {{ count($meta['sections']) }} {{ Str::plural('section', count($meta['sections'])) }}
                                                @else
                                                    No sections yet
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection
