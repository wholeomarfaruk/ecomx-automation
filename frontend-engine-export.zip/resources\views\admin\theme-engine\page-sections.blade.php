@extends('layouts.admin')
@section('content')
    <div class="main-content-inner">
        <div class="main-content-wrap">
            <div class="flex items-center flex-wrap justify-between gap20 mb-27">
                <h3>Page Sections</h3>
                <ul class="breadcrumbs flex items-center flex-wrap justify-start gap10">
                    <li>
                        <a href="{{ route('admin.index') }}">
                            <div class="text-tiny">Dashboard</div>
                        </a>
                    </li>
                    <li>
                        <i class="icon-chevron-right"></i>
                    </li>
                    <li>
                        <div class="text-tiny">Page Sections</div>
                    </li>
                </ul>
            </div>

            <div class="wg-box">
                <p class="body-text mb-20">
                    Toggle sections active/inactive and drag to reorder how they render on the storefront.
                </p>

                @livewire('admin.theme-engine.page-section-manager')
            </div>
        </div>
    </div>
@endsection
