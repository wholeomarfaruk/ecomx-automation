<div>
    <div class="row">
        <div class="col-md-3">
            <div class="nav flex-column nav-pills" role="tablist" aria-orientation="vertical">
                <button type="button" role="tab"
                        class="nav-link {{ $activeTab === 'sections' ? 'active' : '' }}"
                        wire:click="setActiveTab('sections')">
                    <i class="icon-layers me-2"></i>Sections
                </button>
                <button type="button" role="tab"
                        class="nav-link {{ $activeTab === 'seo' ? 'active' : '' }}"
                        wire:click="setActiveTab('seo')">
                    <i class="icon-search me-2"></i>SEO
                </button>
                <button type="button" role="tab"
                        class="nav-link {{ $activeTab === 'others' ? 'active' : '' }}"
                        wire:click="setActiveTab('others')">
                    <i class="icon-settings me-2"></i>Others
                </button>
            </div>
        </div>

        <div class="col-md-9">
            {{-- Sections tab --}}
            <div class="{{ $activeTab === 'sections' ? '' : 'd-none' }}">
                @if (empty($sections))
                    <div class="text-center py-5">
                        <p class="mb-0">No sections configured for this page yet.</p>
                    </div>
                @else
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered align-middle mb-0">
                            <thead>
                                <tr>
                                    <th class="w-auto"></th>
                                    <th>Section</th>
                                    <th>Status</th>
                                    <th>Edit</th>
                                </tr>
                            </thead>
                            <tbody id="section-sortable-body" wire:ignore.self>
                                @foreach ($sections as $section)
                                    <tr wire:key="section-{{ $section['key'] }}" data-key="{{ $section['key'] }}">
                                        <td class="section-drag-handle" style="cursor:grab">
                                            <i class="icon-menu"></i>
                                        </td>
                                        <td>{{ ucwords(str_replace('-', ' ', $section['key'])) }}</td>
                                        <td>
                                            <div class="form-check form-switch mb-0" wire:key="switch-{{ $section['key'] }}-{{ $section['active'] ? '1' : '0' }}">
                                                <input type="checkbox" class="form-check-input" role="switch"
                                                    {{ $section['active'] ? 'checked' : '' }}
                                                    onchange="@this.call('toggleActive', '{{ $section['key'] }}', this.checked)">
                                                <span class="badge {{ $section['active'] ? 'bg-success' : 'bg-secondary' }}">{{ $section['active'] ? 'Active' : 'Inactive' }}</span>
                                            </div>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-outline-primary"
                                                    onclick="Livewire.dispatch('open-section-config-editor', { page: '{{ $page }}', section: '{{ $section['key'] }}' })">
                                                <i class="icon-edit"></i> Edit
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>

            {{-- SEO tab --}}
            <div class="{{ $activeTab === 'seo' ? '' : 'd-none' }}">
                <form wire:submit.prevent="saveSeo">
                    <div class="mb-3">
                        <label class="form-label">Meta Title</label>
                        <input type="text" class="form-control" wire:model="metaTitle" maxlength="255">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Meta Description</label>
                        <textarea class="form-control" rows="4" wire:model="metaDescription" maxlength="500"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">OG Image URL</label>
                        <input type="text" class="form-control" wire:model="ogImage" placeholder="https://...">
                    </div>
                    <button type="submit" class="btn btn-primary">Save SEO Settings</button>
                </form>
            </div>

            {{-- Others tab --}}
            <div class="{{ $activeTab === 'others' ? '' : 'd-none' }}">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h5 class="mb-1">Page Visibility</h5>
                        <p class="text-muted mb-0">Unpublish to hide this page from the storefront without deleting its configuration.</p>
                    </div>
                    <div class="form-check form-switch mb-0" wire:key="published-{{ $published ? '1' : '0' }}">
                        <input type="checkbox" class="form-check-input" role="switch"
                            {{ $published ? 'checked' : '' }}
                            onchange="@this.call('togglePublished', this.checked)">
                        <span>{{ $published ? 'Published' : 'Draft' }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js"></script>
<script>
document.addEventListener('livewire:init', () => {
    let sortable = null;

    const initSortable = () => {
        const el = document.getElementById('section-sortable-body');
        if (!el || el.dataset.sortableInit) return;
        el.dataset.sortableInit = '1';

        sortable = new Sortable(el, {
            handle: '.section-drag-handle',
            animation: 150,
            onEnd: () => {
                const keys = Array.from(el.querySelectorAll('tr')).map(tr => tr.dataset.key);
                const root = el.closest('[wire\\:id]');
                const component = Livewire.find(root.getAttribute('wire:id'));
                component.call('reorder', keys);
            },
        });
    };

    initSortable();
    Livewire.hook('morph.updated', () => {
        const el = document.getElementById('section-sortable-body');
        if (el) delete el.dataset.sortableInit;
        initSortable();
    });
});
</script>
@endpush
